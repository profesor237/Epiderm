<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sufee Admin - HTML5 Admin Template</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body>
    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="images/logo.png" alt="Logo"></a>
                <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php"> <i class="menu-icon fa fa-dashboard"></i>Tableau de bord</a>
                    </li>
                    <h3 class="menu-title">Gestion des cas</h3><!-- /.menu-title -->


                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-laptop"></i>Enregistrer</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-puzzle-piece"></i><a href="nouveau_test.php">Nouveau test</a></li>
                            <li><i class="fa fa-id-badge"></i><a href="nouveau_cas.php">Nouveau cas confirmé</a></li>
                            <li><i class="fa fa-bars"></i><a href="nouveau_gueris.php">Nouveu guéris</a></li>
                            <li><i class="fa fa-share-square-o"></i><a href="nouveau_deces.php">Nouveau décès</a></li>
                            <li><i class="fa fa-exclamation-triangle"></i><a href="nouveau_barriere.php">Nouvelles mésures barrières</a></li>
                            <li><i class="fa fa-spinner"></i><a href="nouveau_symptome.php">Nouveaux symptomes</a></li>
                        </ul>
                    </li>



                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-table"></i>Communication SMS</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-table"></i><a href="sensibilisation.php">Sensibilisation général</a></li>
                            <li><i class="fa fa-table"></i><a href="reponse_suspect.php">Reponse cas suspect</a></li>
                            <li><i class="fa fa-table"></i><a href="rappel_test.php">Rappel de test </a></li>
                        </ul>
                    </li>


                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-th"></i>Lancer l'alerte</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="alerte_generale.php">Alerte générale</a></li>
                            <li><i class="menu-icon fa fa-th"></i><a href="alerte_zone.php">Alerte par zone</a></li>
                        </ul>
                    </li>



                    <h3 class="menu-title">Supports Administratifs</h3><!-- /.menu-title -->

                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Rapports</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="#">Rapports sur les tests</a></li>
                            <li><i class="menu-icon ti-themify-logo"></i><a href="#">Rapports suivi des patients</a></li>
                        </ul>
                    </li>


                    <li>
                        <a href="#"> <i class="#"></i>Demander autorisation d'alerte </a>
                    </li>

                    <h3 class="menu-title">Statistiques</h3><!-- /.menu-title -->                                    
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>graphes</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Courbe évolutive</a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Histogramme</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">Tableau de données</a></li>
                        </ul>
                    </li>


                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <button class="search-trigger"><i class="fa fa-search"></i></button>
                        <div class="form-inline">
                            <form class="search-form">
                                <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jp" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="#"><i class="fa fa-user"></i> Notifications <span class="count">13</span></a>

                            <a class="nav-link" href="#"><i class="fa fa-cog"></i> Settings</a>

                            <a class="nav-link" href="#"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"  id="language" aria-haspopup="true" aria-expanded="true">
                            <i class="flag-icon flag-icon-cmr"></i>
                        </a>
                    </div>

                </div>
            </div>

        </header><!-- /header -->
        <!-- Header--><!-- /header -->
            <!-- Header-->
        
            <div class="breadcrumbs">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>EPIDERM</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li class="active">EPIDERM CHOLERA</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="content mt-3">
        
                <div class="col-sm-12">
                    <div class="alert  alert-danger alert-dismissible fade show" role="alert">
                        <span class="badge badge-pill badge-danger">Alert</span> Un nouveau cas suspect vient d'etre signalé
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
             </div>
        
        
        
                                
        
        
        
        
        
        
        
        
        
                                            <div class="card">
                                                <div class="card-header">
                                                    <strong>Repondre à la denonciation du cas suspect </strong>
                                                    
                                            </small>
                                                </div>
                                                <div class="card-body">
                                                        <section class="page-section" id="contact">
                                                                <div class="container">
                                                                    <!-- Contact Section Heading-->
                                                                    <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Répondre à un cas suspect</h2>
                                                                    <!-- Icon Divider-->
        
                                                                    <div class="divider-custom">
                                                                        <div class="divider-custom-line"></div>
                                                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                                                        <div class="divider-custom-line"></div>
                                                                    </div>
                                                                    <!-- Contact Section Form-->
                                                                    <div class="row">
                                                                        <div class="col-lg-8 mx-auto">
                                                                            <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19.-->
                                                                            <form id="contactForm" name="sentMessage" novalidate="novalidate">
                                                                                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                                                                                        <label for="exampleDataList" class="form-label">Numero du cas</label>
                                                                                        <input class="form-control" list="datalistOptions" id="exampleDataList" placeholder="Type to search...">
                                                                                        <datalist id="datalistOptions">
                                                                                            <option value="694230972">
                                                                                            <option value="675073642">
                                                                                            <option value="680315032">
                                                                                        </datalist>
        
                                                                                </div>
                                                                                <div class="control-group">
                                                                                        <div class="form-group floating-label-form-group controls mb-0 pb-2">
                                                                                            <label>Message </label>
                                                                                            <textarea class="form-control" id="message" rows="5" placeholder="Message" required="required" data-validation-required-message="Please enter a message."></textarea>
                                                                                            <p class="help-block text-danger"></p>
                                                                                        </div>
                                                                                    </div>

                                                                                <br />
                                                                                <div id="success"></div>
                                                                                <div class="form-group"><button class="btn btn-primary btn-xl" id="sendMessageButton" type="submit">Send</button></div>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </section>
                                                </div>
                                            </div><!-- /# card -->
                                        </div>
                                    </div> <!-- .buttons -->
        
                                </div><!-- .row -->
                            </div><!-- .animated -->
                        </div><!-- .content -->
        
        
                    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>


</body>

</html>
